public class Autor {
    private String nome;
    private String tipo; // "Usuário" ou "Autor Tradicional"

    public Autor(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void exibirInfo() {
        System.out.println("Autor: " + nome + " | Tipo: " + tipo);
    }
}
