public class Main {
    public static void main(String[] args) {
        Autor autor = new Autor("Jéssica Félix", "Usuário");
        autor.exibirInfo();

        Artigo artigo = new Artigo("Entendendo Compiladores", autor, "Tecnologia", true);
        artigo.validarPublicacao();

        System.out.println("Artigo: " + artigo.getTitulo());
        System.out.println("Autor: " + artigo.getAutor().getNome());
        System.out.println("Gênero: " + artigo.getGenero());
        System.out.println("Publicado: " + artigo.isPublicado());
    }
}
