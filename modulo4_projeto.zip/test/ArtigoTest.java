import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ArtigoTest {

    @Test
    public void deveCriarArtigoCorretamente() {
        Autor autor = new Autor("Jéssica Félix", "Usuário");
        Artigo artigo = new Artigo("Entendendo Compiladores", autor, "Tecnologia", true);

        assertEquals("Entendendo Compiladores", artigo.getTitulo());
        assertEquals("Tecnologia", artigo.getGenero());
        assertTrue(artigo.isPublicado());
        assertEquals("Jéssica Félix", artigo.getAutor().getNome());
    }
}
