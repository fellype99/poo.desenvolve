import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AutorTest {

    @Test
    public void deveCriarAutorCorretamente() {
        Autor autor = new Autor("Jéssica Félix", "Autor Tradicional");

        assertEquals("Jéssica Félix", autor.getNome());
        assertEquals("Autor Tradicional", autor.getTipo());
    }

    @Test
    public void devePermitirAlterarTipoAutor() {
        Autor autor = new Autor("Lucas", "Usuário");
        autor.setTipo("Autor Tradicional");

        assertEquals("Autor Tradicional", autor.getTipo());
    }
}
