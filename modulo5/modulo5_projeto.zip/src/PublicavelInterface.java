public interface PublicavelInterface {
    void publicar();
}
