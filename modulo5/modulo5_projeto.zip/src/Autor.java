public class Autor implements PublicavelInterface {
    private String nome;
    private String tipo;
    private EstrategiaPublicacao estrategiaPublicacao;

    public Autor(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    public String getNome() {
        return nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setEstrategiaPublicacao(EstrategiaPublicacao estrategiaPublicacao) {
        this.estrategiaPublicacao = estrategiaPublicacao;
    }

    @Override
    public void publicar() {
        if (estrategiaPublicacao == null) {
            System.out.println("⚠️ Nenhuma estratégia de publicação definida para o autor " + nome);
        } else {
            estrategiaPublicacao.executarPublicacao("Conteúdo genérico", nome);
        }
    }

    public void publicar(String titulo) {
        if (estrategiaPublicacao == null) {
            System.out.println("⚠️ Nenhuma estratégia de publicação definida para o autor " + nome);
        } else {
            estrategiaPublicacao.executarPublicacao(titulo, nome);
        }
    }
}
