public class EstrategiaPublicacaoLivro implements EstrategiaPublicacao {
    @Override
    public void executarPublicacao(String titulo, String autor) {
        System.out.println("📘 Publicando livro: \"" + titulo + "\" de " + autor);
    }
}
