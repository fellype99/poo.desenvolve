public interface EstrategiaPublicacao {
    void executarPublicacao(String titulo, String autor);
}
