public class Main {
    public static void main(String[] args) {
        Autor autor1 = new Autor("Jéssica Félix", "Autor Tradicional");
        Autor autor2 = new Autor("Lucas", "Usuário");

        autor1.setEstrategiaPublicacao(new EstrategiaPublicacaoArtigo());
        autor2.setEstrategiaPublicacao(new EstrategiaPublicacaoLivro());

        autor1.publicar("Entendendo Compiladores");
        autor2.publicar("Java para Iniciantes");
    }
}
