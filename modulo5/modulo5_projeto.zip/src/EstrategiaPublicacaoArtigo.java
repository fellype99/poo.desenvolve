public class EstrategiaPublicacaoArtigo implements EstrategiaPublicacao {
    @Override
    public void executarPublicacao(String titulo, String autor) {
        System.out.println("📰 Publicando artigo: \"" + titulo + "\" de " + autor);
    }
}
