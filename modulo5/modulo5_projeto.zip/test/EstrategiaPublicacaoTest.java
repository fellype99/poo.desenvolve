import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EstrategiaPublicacaoTest {

    @Test
    public void deveAplicarEstrategiaDeArtigo() {
        Autor autor = new Autor("Maria", "Usuário");
        EstrategiaPublicacao estrategia = new EstrategiaPublicacaoArtigo();
        autor.setEstrategiaPublicacao(estrategia);

        assertDoesNotThrow(() -> autor.publicar("POO na prática"));
    }

    @Test
    public void deveAplicarEstrategiaDeLivro() {
        Autor autor = new Autor("João", "Autor Tradicional");
        EstrategiaPublicacao estrategia = new EstrategiaPublicacaoLivro();
        autor.setEstrategiaPublicacao(estrategia);

        assertDoesNotThrow(() -> autor.publicar("SOLID descomplicado"));
    }

    @Test
    public void deveAlertarQuandoNaoHouverEstrategia() {
        Autor autor = new Autor("Ana", "Usuário");
        assertDoesNotThrow(() -> autor.publicar("Título qualquer"));
    }
}
